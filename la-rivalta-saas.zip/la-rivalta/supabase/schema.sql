-- ============================================================
-- Schéma de base de données — La Rivalta Click & Collect
-- À exécuter dans Supabase : SQL Editor > New query > Run
-- ============================================================

create extension if not exists pgcrypto;

-- Carte des pizzas
create table if not exists pizzas (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text default '',
  price numeric(6,2) not null,
  available boolean not null default true,
  created_at timestamptz default now()
);

-- Créneaux de retrait
create table if not exists slots (
  id uuid primary key default gen_random_uuid(),
  time text not null,          -- format 'HH:MM'
  capacity int not null default 3,
  closed boolean not null default false
);

-- Commandes
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null,
  customer_name text not null,
  items jsonb not null,                     -- [{pizza_id, name, qty, price}]
  total numeric(8,2) not null,
  slot_id uuid references slots(id),
  slot_time text,
  payment_method text not null,             -- 'online' | 'onsite'
  payment_status text not null default 'en_attente',  -- 'en_attente' | 'payee'
  status text not null default 'nouvelle',  -- nouvelle | en_preparation | prete | recuperee
  stripe_session_id text,
  created_at timestamptz default now()
);

-- Réglages généraux (une seule ligne)
create table if not exists settings (
  id int primary key default 1,
  pizzeria_name text not null default 'La Rivalta',
  is_open boolean not null default true
);
insert into settings (id) values (1) on conflict (id) do nothing;

-- ============================================================
-- Données de démarrage (à adapter/supprimer ensuite)
-- ============================================================
insert into pizzas (name, description, price, available) values
  ('Margherita', 'Tomate San Marzano, mozzarella fior di latte, basilic frais', 11, true),
  ('Reine', 'Tomate, mozzarella, jambon blanc, champignons', 13, true),
  ('Quatre Fromages', 'Mozzarella, gorgonzola, parmesan, chèvre', 14, true),
  ('Diavola', 'Tomate, mozzarella, salami piquant, huile pimentée', 13.5, true),
  ('Végétarienne', 'Légumes grillés de saison, mozzarella, pesto', 13, true)
on conflict do nothing;

insert into slots (time, capacity) values
  ('11:30',3),('11:45',3),('12:00',3),('12:15',3),('12:30',3),('12:45',3),('13:00',3),('13:15',3),('13:30',3),
  ('18:30',3),('18:45',3),('19:00',3),('19:15',3),('19:30',3),('19:45',3),('20:00',3),('20:15',3),('20:30',3),('20:45',3),('21:00',3),('21:15',3),('21:30',3)
on conflict do nothing;

-- ============================================================
-- Sécurité (Row Level Security)
-- ============================================================
alter table pizzas enable row level security;
alter table slots enable row level security;
alter table orders enable row level security;
alter table settings enable row level security;

-- Lecture publique (le client doit voir la carte, les créneaux, l'état d'ouverture)
create policy "public read pizzas" on pizzas for select using (true);
create policy "public read slots" on slots for select using (true);
create policy "public read settings" on settings for select using (true);

-- Le pizzaiolo (connecté via Supabase Auth) peut tout modifier
create policy "staff write pizzas" on pizzas for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "staff write slots" on slots for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "staff write settings" on settings for update
  using (auth.role() = 'authenticated');

-- Commandes : le client peut créer une commande et relire CELLE qu'il vient de créer
create policy "public insert orders" on orders for insert with check (true);
create policy "public read orders" on orders for select using (true);
create policy "staff update orders" on orders for update
  using (auth.role() = 'authenticated');

-- ⚠️ Note sécurité : la policy "public read orders" est volontairement permissive
-- pour rester simple en v1 (le client relit sa commande via son lien de confirmation).
-- Cela signifie que quelqu'un qui devine/collecte des IDs de commande pourrait les lire.
-- Avant une vraie mise en production à grande échelle, il est recommandé de faire
-- relire les commandes via une route API sécurisée plutôt qu'en lecture directe.
