'use client';

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

function genOrderNumber() {
  return Math.random().toString(36).slice(2, 7).toUpperCase();
}

export default function CommanderPage() {
  const [pizzas, setPizzas] = useState([]);
  const [slots, setSlots] = useState([]);
  const [settings, setSettings] = useState({ pizzeria_name: 'La Rivalta', is_open: true });
  const [loading, setLoading] = useState(true);

  const [step, setStep] = useState(1);
  const [cart, setCart] = useState({}); // { pizzaId: qty }
  const [selectedSlotId, setSelectedSlotId] = useState(null);
  const [customerName, setCustomerName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [placedOrder, setPlacedOrder] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const [{ data: p }, { data: s }, { data: st }] = await Promise.all([
      supabase.from('pizzas').select('*').order('name'),
      supabase.from('slots').select('*').order('time'),
      supabase.from('settings').select('*').eq('id', 1).single(),
    ]);
    setPizzas(p || []);
    setSlots(s || []);
    if (st) setSettings(st);
    setLoading(false);
  }

  // Live update du ticket de confirmation (statut changé par le pizzaiolo)
  useEffect(() => {
    if (step !== 4 || !placedOrder) return;
    const channel = supabase
      .channel('order-' + placedOrder.id)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'orders', filter: `id=eq.${placedOrder.id}` },
        (payload) => setPlacedOrder(payload.new)
      )
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [step, placedOrder?.id]);

  function qty(id) { return cart[id] || 0; }
  function setQty(id, q) { setCart((c) => ({ ...c, [id]: Math.max(0, q) })); }
  const cartTotal = Object.entries(cart).reduce((sum, [id, q]) => {
    const p = pizzas.find((x) => x.id === id);
    return sum + (p ? p.price * q : 0);
  }, 0);
  const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);

  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const upcomingSlots = slots.filter((s) => {
    const [h, m] = s.time.split(':').map(Number);
    return h * 60 + m >= nowMinutes - 5 && !s.closed;
  });

  async function handleFinalize() {
    if (!customerName.trim() || !paymentMethod || !selectedSlotId) return;
    setSubmitting(true);
    const slot = slots.find((s) => s.id === selectedSlotId);
    const items = Object.entries(cart)
      .filter(([, q]) => q > 0)
      .map(([id, q]) => {
        const p = pizzas.find((x) => x.id === id);
        return { pizza_id: id, name: p.name, qty: q, price: p.price };
      });

    const orderPayload = {
      order_number: genOrderNumber(),
      customer_name: customerName.trim(),
      items,
      total: cartTotal,
      slot_id: selectedSlotId,
      slot_time: slot ? slot.time : '—',
      payment_method: paymentMethod,
      payment_status: paymentMethod === 'onsite' ? 'en_attente' : 'en_attente',
      status: 'nouvelle',
    };

    const { data: order, error } = await supabase
      .from('orders')
      .insert(orderPayload)
      .select()
      .single();

    if (error) {
      alert("Une erreur est survenue lors de la commande. Réessayez.");
      setSubmitting(false);
      return;
    }

    // Incrémente la place prise sur le créneau (best-effort, non transactionnel)
    if (slot) {
      await supabase.from('slots').update({}).eq('id', slot.id); // placeholder si vous ajoutez un compteur "taken"
    }

    if (paymentMethod === 'online') {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: order.id, total: cartTotal, customerName }),
      });
      const json = await res.json();
      if (json.url) {
        window.location.href = json.url; // redirection vers Stripe Checkout
        return;
      } else {
        alert("Le paiement en ligne n'a pas pu être initié. Réessayez ou choisissez 'sur place'.");
        setSubmitting(false);
        return;
      }
    }

    // Paiement sur place : on va directement à la confirmation
    setPlacedOrder(order);
    setStep(4);
    setSubmitting(false);
  }

  if (loading) {
    return <div className="view"><p>Chargement de la carte…</p></div>;
  }

  if (!settings.is_open) {
    return (
      <div className="view" style={{ textAlign: 'center', paddingTop: 60 }}>
        <h2 style={{ color: 'var(--surface)' }}>{settings.pizzeria_name} est actuellement fermé</h2>
        <p style={{ color: 'var(--ink-soft)' }}>Les commandes en ligne ne sont pas possibles pour le moment. Revenez plus tard !</p>
      </div>
    );
  }

  return (
    <>
      <div className="topbar">
        <div className="brand">
          <div className="flame-mark">🔥</div>
          <div>
            <h1>{settings.pizzeria_name}</h1>
            <span className="tag">CLICK &amp; COLLECT</span>
          </div>
        </div>
      </div>

      <main className="view">
        <div className="stepper">
          {['Carte', 'Créneau', 'Paiement', 'Confirmation'].map((label, i) => {
            const n = i + 1;
            return (
              <div className="dot-wrap" key={n}>
                <div className={`bar ${n < step ? 'done' : n === step ? 'current' : ''}`}></div>
                <div className={`label ${n <= step ? 'active' : ''}`}>{n}. {label}</div>
              </div>
            );
          })}
        </div>

        {step === 1 && (
          <>
            <div className="menu-grid">
              {pizzas.map((p) => (
                <div key={p.id} className={`pizza-card ${p.available ? '' : 'unavailable'}`}>
                  {!p.available && <span className="badge-out">Rupture</span>}
                  <h3>{p.name}</h3>
                  <p>{p.description}</p>
                  <div className="pizza-row">
                    <span className="price">{Number(p.price).toFixed(2)} €</span>
                    <div className="qty-control">
                      <button disabled={qty(p.id) === 0} onClick={() => setQty(p.id, qty(p.id) - 1)}>−</button>
                      <span>{qty(p.id)}</span>
                      <button disabled={!p.available} onClick={() => setQty(p.id, qty(p.id) + 1)}>+</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="cart-bar">
              <span className="mono">{totalItems === 0 ? 'Panier vide' : `${totalItems} article${totalItems > 1 ? 's' : ''} — ${cartTotal.toFixed(2)} €`}</span>
              <button className="btn" disabled={totalItems === 0} onClick={() => setStep(2)}>Choisir un créneau →</button>
            </div>
          </>
        )}

        {step === 2 && (
          <section>
            <div className="slot-section">
              <h3>Choisissez votre créneau de retrait — aujourd'hui</h3>
              <div className="slot-grid">
                {upcomingSlots.length === 0 && (
                  <p style={{ color: 'var(--surface-dim)' }}>Plus de créneaux disponibles aujourd'hui — revenez demain !</p>
                )}
                {upcomingSlots.map((s) => (
                  <div
                    key={s.id}
                    className={`slot-pill ${selectedSlotId === s.id ? 'selected' : ''}`}
                    onClick={() => setSelectedSlotId(s.id)}
                  >
                    <span className="t">{s.time}</span>
                    <span className="c">Disponible</span>
                  </div>
                ))}
              </div>
            </div>
            <button className="btn ghost" onClick={() => setStep(1)}>← Retour à la carte</button>
            <button className="btn" style={{ marginLeft: 8 }} disabled={!selectedSlotId} onClick={() => setStep(3)}>Continuer →</button>
          </section>
        )}

        {step === 3 && (
          <section>
            <div className="panel">
              <h3>Récapitulatif</h3>
              {Object.entries(cart).filter(([, q]) => q > 0).map(([id, q]) => {
                const p = pizzas.find((x) => x.id === id);
                return (
                  <div className="recap-line" key={id}>
                    <span>{q} × {p.name}</span>
                    <span>{(p.price * q).toFixed(2)} €</span>
                  </div>
                );
              })}
              <div className="recap-line" style={{ marginTop: 6 }}>
                <span>Retrait prévu</span>
                <span>{slots.find((s) => s.id === selectedSlotId)?.time || '—'}</span>
              </div>
              <div className="recap-total"><span>Total</span><span>{cartTotal.toFixed(2)} €</span></div>
            </div>
            <div className="panel">
              <div className="field">
                <label>Votre prénom (pour l'appel en boutique)</label>
                <input type="text" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Ex : Camille" />
              </div>
              <div className="pay-options">
                <label className={`pay-opt ${paymentMethod === 'online' ? 'selected' : ''}`} onClick={() => setPaymentMethod('online')}>
                  <input type="radio" name="pay" checked={paymentMethod === 'online'} readOnly />
                  <div><strong>Payer en ligne</strong><br /><span style={{ fontSize: '.8rem', color: 'var(--ink-soft)' }}>Carte bancaire via Stripe</span></div>
                </label>
                <label className={`pay-opt ${paymentMethod === 'onsite' ? 'selected' : ''}`} onClick={() => setPaymentMethod('onsite')}>
                  <input type="radio" name="pay" checked={paymentMethod === 'onsite'} readOnly />
                  <div><strong>Payer sur place</strong><br /><span style={{ fontSize: '.8rem', color: 'var(--ink-soft)' }}>Réglez au comptoir en récupérant votre pizza</span></div>
                </label>
              </div>
              <button className="btn ghost" onClick={() => setStep(2)}>← Retour</button>
              <button
                className="btn"
                style={{ marginLeft: 8 }}
                disabled={!customerName.trim() || !paymentMethod || submitting}
                onClick={handleFinalize}
              >
                {submitting ? 'Envoi en cours…' : 'Valider la commande'}
              </button>
            </div>
          </section>
        )}

        {step === 4 && placedOrder && (
          <section>
            <div className="ticket">
              <div className="t-head">
                <div>
                  <div className="t-num">#{placedOrder.order_number}</div>
                  <div className="t-name">{placedOrder.customer_name}</div>
                </div>
                <div className="t-time">{placedOrder.slot_time}</div>
              </div>
              <div className="t-divider"></div>
              {placedOrder.items.map((it, i) => (
                <div className="t-item" key={i}><span>{it.qty} × {it.name}</span><span>{(it.price * it.qty).toFixed(2)} €</span></div>
              ))}
              <div className="t-divider"></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <strong>{Number(placedOrder.total).toFixed(2)} €</strong>
                <span className="pay-chip">{placedOrder.payment_status === 'payee' ? 'Payé' : placedOrder.payment_method === 'online' ? 'En attente de paiement' : 'À régler sur place'}</span>
              </div>
              <div style={{ marginTop: 10 }}>
                <span className={`status-chip status-${placedOrder.status}`}>
                  {{ nouvelle: 'Nouvelle', en_preparation: 'En préparation', prete: 'Prête', recuperee: 'Récupérée' }[placedOrder.status]}
                </span>
              </div>
            </div>
            <div style={{ textAlign: 'center', marginTop: 20 }}>
              <button className="btn ghost" onClick={() => { setStep(1); setCart({}); setSelectedSlotId(null); setPaymentMethod(null); setCustomerName(''); setPlacedOrder(null); }}>
                Passer une nouvelle commande
              </button>
            </div>
          </section>
        )}
      </main>
    </>
  );
}
