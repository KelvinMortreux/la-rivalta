'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { supabase } from '../../../lib/supabaseClient';

const STATUS_LABEL = { nouvelle: 'Nouvelle', en_preparation: 'En préparation', prete: 'Prête', recuperee: 'Récupérée' };

export default function ConfirmationPage() {
  const params = useSearchParams();
  const orderId = params.get('order');
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;
    load();
    const channel = supabase
      .channel('order-confirm-' + orderId)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'orders', filter: `id=eq.${orderId}` },
        (payload) => setOrder(payload.new)
      )
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [orderId]);

  async function load() {
    const { data } = await supabase.from('orders').select('*').eq('id', orderId).single();
    setOrder(data);
    setLoading(false);
  }

  if (!orderId) return <div className="view"><p>Commande introuvable.</p></div>;
  if (loading) return <div className="view"><p>Chargement…</p></div>;
  if (!order) return <div className="view"><p>Commande introuvable.</p></div>;

  return (
    <main className="view">
      <div className="ticket">
        <div className="t-head">
          <div>
            <div className="t-num">#{order.order_number}</div>
            <div className="t-name">{order.customer_name}</div>
          </div>
          <div className="t-time">{order.slot_time}</div>
        </div>
        <div className="t-divider"></div>
        {order.items.map((it, i) => (
          <div className="t-item" key={i}><span>{it.qty} × {it.name}</span><span>{(it.price * it.qty).toFixed(2)} €</span></div>
        ))}
        <div className="t-divider"></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <strong>{Number(order.total).toFixed(2)} €</strong>
          <span className="pay-chip">{order.payment_status === 'payee' ? 'Payé' : 'En attente de paiement'}</span>
        </div>
        <div style={{ marginTop: 10 }}>
          <span className={`status-chip status-${order.status}`}>{STATUS_LABEL[order.status]}</span>
        </div>
      </div>
      <div style={{ textAlign: 'center', marginTop: 20 }}>
        <a href="/commander" className="btn ghost">Passer une nouvelle commande</a>
      </div>
    </main>
  );
}
