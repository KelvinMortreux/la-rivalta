import { NextResponse } from 'next/server';
import { stripe } from '../../../lib/stripe';

export async function POST(req) {
  try {
    const { orderId, total, customerName } = await req.json();
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'eur',
            unit_amount: Math.round(total * 100), // Stripe attend des centimes
            product_data: { name: `Commande La Rivalta — ${customerName}` },
          },
          quantity: 1,
        },
      ],
      metadata: { order_id: orderId },
      success_url: `${siteUrl}/commander/confirmation?order=${orderId}`,
      cancel_url: `${siteUrl}/commander?cancelled=1`,
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'checkout_failed' }, { status: 500 });
  }
}
