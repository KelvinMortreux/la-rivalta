import './globals.css';

export const metadata = {
  title: 'La Rivalta — Click & Collect',
  description: 'Commandez vos pizzas en ligne, retirez-les sur place.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
