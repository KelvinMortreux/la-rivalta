import Link from 'next/link';

export default function Home() {
  return (
    <div className="view" style={{ textAlign: 'center', paddingTop: 80 }}>
      <h1 style={{ fontSize: '2rem', color: 'var(--surface)' }}>La Rivalta</h1>
      <p style={{ color: 'var(--ink-soft)', marginBottom: 30 }}>
        Commandez vos pizzas en ligne, retirez-les sur place.
      </p>
      <Link href="/commander" className="btn" style={{ display: 'inline-block' }}>
        Commander une pizza
      </Link>
      <div style={{ marginTop: 16 }}>
        <Link href="/pizzaiolo" style={{ color: 'var(--ink-soft)', fontSize: '0.85rem' }}>
          Espace pizzaiolo →
        </Link>
      </div>
    </div>
  );
}
