'use client';

import { useEffect, useRef, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

const STATUS_LABEL = { nouvelle: 'Nouvelle', en_preparation: 'En préparation', prete: 'Prête', recuperee: 'Récupérée' };

export default function PizzaioloPage() {
  const [session, setSession] = useState(undefined); // undefined = en cours de vérification
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => setSession(sess));
    return () => sub.subscription.unsubscribe();
  }, []);

  async function handleLogin(e) {
    e.preventDefault();
    setLoginError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setLoginError("Identifiants incorrects.");
  }

  if (session === undefined) {
    return <div className="view"><p>Chargement…</p></div>;
  }

  if (!session) {
    return (
      <div className="login-box">
        <h2 style={{ marginTop: 0 }}>Espace pizzaiolo</h2>
        <form onSubmit={handleLogin}>
          <div className="field">
            <label>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="field">
            <label>Mot de passe</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          {loginError && <p style={{ color: 'var(--marzano)', fontSize: '.85rem' }}>{loginError}</p>}
          <button className="btn" type="submit" style={{ width: '100%' }}>Se connecter</button>
        </form>
        <p style={{ fontSize: '.75rem', color: 'var(--ink-soft)', marginTop: 14 }}>
          Compte créé depuis Supabase → Authentication → Users.
        </p>
      </div>
    );
  }

  return <Dashboard onLogout={() => supabase.auth.signOut()} />;
}

function Dashboard({ onLogout }) {
  const [orders, setOrders] = useState([]);
  const [slots, setSlots] = useState([]);
  const [menu, setMenu] = useState([]);
  const [settings, setSettings] = useState({ pizzeria_name: 'La Rivalta', is_open: true });
  const [alert, setAlert] = useState(null);
  const [openSlots, setOpenSlots] = useState(false);
  const [openMenu, setOpenMenu] = useState(false);
  const [newSlotTime, setNewSlotTime] = useState('');
  const [newSlotCap, setNewSlotCap] = useState(3);
  const [newPizzaName, setNewPizzaName] = useState('');
  const [newPizzaDesc, setNewPizzaDesc] = useState('');
  const [newPizzaPrice, setNewPizzaPrice] = useState('');
  const audioCtxRef = useRef(null);

  useEffect(() => {
    loadAll();
    const channel = supabase
      .channel('orders-realtime')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'orders' }, (payload) => {
        setOrders((prev) => [payload.new, ...prev]);
        playChime();
        setAlert(`Nouvelle commande — ${payload.new.customer_name} (${payload.new.slot_time})`);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders' }, (payload) => {
        setOrders((prev) => prev.map((o) => (o.id === payload.new.id ? payload.new : o)));
      })
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, []);

  async function loadAll() {
    const [{ data: o }, { data: s }, { data: m }, { data: st }] = await Promise.all([
      supabase.from('orders').select('*').order('created_at', { ascending: false }),
      supabase.from('slots').select('*').order('time'),
      supabase.from('pizzas').select('*').order('name'),
      supabase.from('settings').select('*').eq('id', 1).single(),
    ]);
    setOrders(o || []);
    setSlots(s || []);
    setMenu(m || []);
    if (st) setSettings(st);
  }

  function playChime() {
    try {
      const ctx = audioCtxRef.current || new (window.AudioContext || window.webkitAudioContext)();
      audioCtxRef.current = ctx;
      [880, 1175].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.18);
        gain.gain.exponentialRampToValueAtTime(0.35, ctx.currentTime + i * 0.18 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.18 + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.18);
        osc.stop(ctx.currentTime + i * 0.18 + 0.4);
      });
    } catch (e) { /* audio indisponible */ }
  }

  async function setStatus(id, status) {
    await supabase.from('orders').update({ status }).eq('id', id);
  }

  async function toggleOpen() {
    const next = !settings.is_open;
    setSettings((s) => ({ ...s, is_open: next }));
    await supabase.from('settings').update({ is_open: next }).eq('id', 1);
  }

  async function toggleSlotClosed(slot) {
    await supabase.from('slots').update({ closed: !slot.closed }).eq('id', slot.id);
    loadAll();
  }
  async function removeSlot(id) {
    await supabase.from('slots').delete().eq('id', id);
    loadAll();
  }
  async function addSlot() {
    if (!newSlotTime) return;
    await supabase.from('slots').insert({ time: newSlotTime, capacity: Number(newSlotCap) || 1 });
    setNewSlotTime('');
    loadAll();
  }
  async function togglePizzaAvailable(p) {
    await supabase.from('pizzas').update({ available: !p.available }).eq('id', p.id);
    loadAll();
  }
  async function addPizza() {
    if (!newPizzaName.trim() || newPizzaPrice === '') return;
    await supabase.from('pizzas').insert({
      name: newPizzaName.trim(),
      description: newPizzaDesc.trim(),
      price: Number(newPizzaPrice),
      available: true,
    });
    setNewPizzaName(''); setNewPizzaDesc(''); setNewPizzaPrice('');
    loadAll();
  }

  const nouvelles = orders.filter((o) => o.status === 'nouvelle');
  const prep = orders.filter((o) => o.status === 'en_preparation');
  const pretes = orders.filter((o) => o.status === 'prete');

  function renderTicket(o) {
    let actionBtn = null;
    if (o.status === 'nouvelle') actionBtn = <button className="btn small" onClick={() => setStatus(o.id, 'en_preparation')}>Lancer en préparation</button>;
    if (o.status === 'en_preparation') actionBtn = <button className="btn small basil" onClick={() => setStatus(o.id, 'prete')}>Marquer prête</button>;
    if (o.status === 'prete') actionBtn = <button className="btn small ghost" onClick={() => setStatus(o.id, 'recuperee')}>Marquer récupérée</button>;
    return (
      <div className="ticket board" key={o.id}>
        <div className="t-head">
          <div>
            <div className="t-num">#{o.order_number}</div>
            <div className="t-name">{o.customer_name}</div>
          </div>
          <div className="t-time">{o.slot_time}</div>
        </div>
        <div className="t-divider"></div>
        {o.items.map((it, i) => (
          <div className="t-item" key={i}><span>{it.qty} × {it.name}</span><span>{(it.price * it.qty).toFixed(2)} €</span></div>
        ))}
        <div className="t-divider"></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <strong>{Number(o.total).toFixed(2)} €</strong>
          <span className="pay-chip">{o.payment_method === 'online' ? (o.payment_status === 'payee' ? 'Payé' : 'Paiement en attente') : 'À régler sur place'}</span>
        </div>
        <div style={{ marginTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span className={`status-chip status-${o.status}`}>{STATUS_LABEL[o.status]}</span>
          {actionBtn}
        </div>
      </div>
    );
  }

  return (
    <div className="view">
      <div className="dash-header">
        <div className="open-toggle">
          <button className={`switch ${settings.is_open ? 'on' : ''}`} onClick={toggleOpen}></button>
          <span style={{ fontWeight: 600 }}>{settings.is_open ? 'Atelier ouvert aux commandes' : 'Atelier fermé — commandes suspendues'}</span>
        </div>
        <button className="btn ghost small" onClick={onLogout}>Se déconnecter</button>
      </div>

      {alert && (
        <div className="alert-banner show">
          <span>🔔</span><span>{alert}</span>
          <button onClick={() => setAlert(null)}>OK</button>
        </div>
      )}

      <div className="board">
        <div className="col">
          <h3>Nouvelles <span className="col-count">{nouvelles.length}</span></h3>
          <div className="ticket-list">{nouvelles.length ? nouvelles.map(renderTicket) : <div className="empty">Aucune commande</div>}</div>
        </div>
        <div className="col">
          <h3>En préparation <span className="col-count">{prep.length}</span></h3>
          <div className="ticket-list">{prep.length ? prep.map(renderTicket) : <div className="empty">Aucune commande</div>}</div>
        </div>
        <div className="col">
          <h3>Prêtes <span className="col-count">{pretes.length}</span></h3>
          <div className="ticket-list">{pretes.length ? pretes.map(renderTicket) : <div className="empty">Aucune commande</div>}</div>
        </div>
      </div>

      <div style={{ marginTop: 26, borderTop: '1px solid rgba(255,255,255,.08)', paddingTop: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', cursor: 'pointer' }} onClick={() => setOpenSlots(!openSlots)}>
          <h3 style={{ margin: 0, color: 'var(--surface)' }}>⏱ Gérer les créneaux du jour</h3><span>▾</span>
        </div>
        {openSlots && (
          <div style={{ padding: '10px 0 20px' }}>
            {slots.map((s) => (
              <div className="mgmt-row" key={s.id}>
                <span className="mono" style={{ width: 60 }}>{s.time}</span>
                <span className="grow">Capacité : {s.capacity}</span>
                <button className={`toggle-avail ${s.closed ? 'no' : 'yes'}`} onClick={() => toggleSlotClosed(s)}>{s.closed ? 'Fermé' : 'Ouvert'}</button>
                <button className="btn small ghost" onClick={() => removeSlot(s.id)}>Supprimer</button>
              </div>
            ))}
            <div className="add-form">
              <input type="time" value={newSlotTime} onChange={(e) => setNewSlotTime(e.target.value)} step="900" />
              <input type="number" min="1" value={newSlotCap} onChange={(e) => setNewSlotCap(e.target.value)} style={{ width: 90 }} />
              <button className="btn small basil" onClick={addSlot}>Ajouter le créneau</button>
            </div>
          </div>
        )}
      </div>

      <div style={{ marginTop: 10, borderTop: '1px solid rgba(255,255,255,.08)', paddingTop: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', cursor: 'pointer' }} onClick={() => setOpenMenu(!openMenu)}>
          <h3 style={{ margin: 0, color: 'var(--surface)' }}>🍕 Gérer la carte</h3><span>▾</span>
        </div>
        {openMenu && (
          <div style={{ padding: '10px 0 20px' }}>
            {menu.map((p) => (
              <div className="mgmt-row" key={p.id}>
                <span className="grow"><strong>{p.name}</strong> — {Number(p.price).toFixed(2)} €</span>
                <button className={`toggle-avail ${p.available ? 'yes' : 'no'}`} onClick={() => togglePizzaAvailable(p)}>{p.available ? 'Disponible' : 'Rupture'}</button>
              </div>
            ))}
            <div className="add-form">
              <input type="text" placeholder="Nom" value={newPizzaName} onChange={(e) => setNewPizzaName(e.target.value)} />
              <input type="text" placeholder="Description" value={newPizzaDesc} onChange={(e) => setNewPizzaDesc(e.target.value)} style={{ minWidth: 180 }} />
              <input type="number" placeholder="Prix €" min="0" step="0.5" value={newPizzaPrice} onChange={(e) => setNewPizzaPrice(e.target.value)} style={{ width: 80 }} />
              <button className="btn small basil" onClick={addPizza}>Ajouter la pizza</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
