# La Rivalta — Click & Collect

Application complète : carte des pizzas, choix de créneau, paiement en ligne (Stripe) ou sur place,
tableau de bord pizzaiolo en temps réel avec alerte sonore à chaque nouvelle commande.

Ce guide suppose que tu n'es pas développeur. Suis les étapes dans l'ordre, sans en sauter.
Compte-temps réaliste : 45 à 90 minutes la première fois.

---

## Étape 0 — Ce dont tu as besoin

- Une adresse email
- Une carte bancaire (pour créer le compte Stripe — aucun prélèvement tant que tu n'actives pas les vrais paiements)
- Un navigateur, rien d'autre à installer sur ton ordinateur

---

## Étape 1 — Créer la base de données (Supabase)

1. Va sur https://supabase.com → **Start your project** → crée un compte gratuit
2. Clique sur **New project**, donne-lui un nom (ex : `la-rivalta`), choisis un mot de passe de base de données (note-le), choisis une région proche de toi (ex : Paris/Frankfurt)
3. Une fois le projet créé, va dans l'onglet **SQL Editor** (menu de gauche) → **New query**
4. Ouvre le fichier `supabase/schema.sql` de ce projet, copie tout son contenu, colle-le dans l'éditeur, puis clique sur **Run**
   → Cela crée toutes les tables (pizzas, créneaux, commandes, réglages) et charge une carte de démarrage
5. Va dans **Database → Replication** (ou **Database → Publications** selon la version) et assure-toi que la table `orders` a bien la réplication temps réel activée (coche "Insert" et "Update"). C'est ce qui permet l'alerte instantanée côté pizzaiolo.
6. Va dans **Project Settings → API**. Note ces 3 valeurs, tu en auras besoin à l'étape 4 :
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (⚠️ à garder secrète, ne jamais la partager)
7. Va dans **Authentication → Users → Add user** et crée le compte du pizzaiolo (son email + un mot de passe). C'est ce compte qui donnera accès à l'espace pizzaiolo (`/pizzaiolo`).

---

## Étape 2 — Créer le compte de paiement (Stripe)

1. Va sur https://stripe.com → crée un compte gratuit
2. Reste en **mode Test** pour l'instant (interrupteur en haut à droite du tableau de bord Stripe)
3. Va dans **Développeurs → Clés API**. Note la **clé secrète** (commence par `sk_test_...`) → ce sera `STRIPE_SECRET_KEY`
4. On configurera le **webhook** (`STRIPE_WEBHOOK_SECRET`) à l'étape 4, une fois le site en ligne (Stripe a besoin d'une vraie adresse pour l'appeler).

---

## Étape 3 — Mettre le code sur GitHub

1. Va sur https://github.com → crée un compte gratuit
2. Clique sur **New repository**, nomme-le `la-rivalta`, laisse-le en **Public** ou **Private** (les deux fonctionnent), ne coche aucune case additionnelle, clique **Create repository**
3. Sur la page qui s'affiche, clique sur **uploading an existing file**
4. Glisse-dépose **tous les fichiers et dossiers de ce projet** dans la zone (tu peux sélectionner tout le dossier `la-rivalta` d'un coup dans ton explorateur de fichiers)
5. En bas de page, clique **Commit changes**

---

## Étape 4 — Mettre le site en ligne (Vercel)

1. Va sur https://vercel.com → **Sign up** → choisis **Continue with GitHub** (ça relie directement ton compte)
2. Clique **Add New… → Project**, choisis ton dépôt `la-rivalta`, clique **Import**
3. Avant de cliquer sur Deploy, ouvre la section **Environment Variables** et ajoute une par une les variables suivantes (valeurs récupérées aux étapes précédentes) :

   | Nom | Valeur |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | ton URL Supabase |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | ta clé anon Supabase |
   | `SUPABASE_SERVICE_ROLE_KEY` | ta clé service_role Supabase |
   | `STRIPE_SECRET_KEY` | ta clé secrète Stripe (test) |
   | `STRIPE_WEBHOOK_SECRET` | laisse vide pour l'instant, on la complète juste après |
   | `NEXT_PUBLIC_SITE_URL` | laisse vide pour l'instant, on la complète juste après |

4. Clique **Deploy**. Après 1 à 2 minutes, Vercel te donne une URL du type `https://la-rivalta.vercel.app`
5. Retourne dans **Project Settings → Environment Variables** et complète maintenant :
   - `NEXT_PUBLIC_SITE_URL` = ton URL Vercel (ex : `https://la-rivalta.vercel.app`)
6. Va sur Stripe → **Développeurs → Webhooks → Add endpoint** :
   - URL à appeler : `https://la-rivalta.vercel.app/api/webhook`
   - Événement à écouter : `checkout.session.completed`
   - Une fois créé, Stripe affiche une **clé de signature** (`whsec_...`) → colle-la dans Vercel comme `STRIPE_WEBHOOK_SECRET`
7. Retourne dans Vercel → onglet **Deployments** → clique les `...` sur le dernier déploiement → **Redeploy** (pour que les nouvelles variables soient prises en compte)

Ton site est en ligne et fonctionnel, en mode paiement **test**.

---

## Étape 5 — Tester de bout en bout

1. Ouvre `https://ton-url.vercel.app/commander` → passe une commande test
2. Pour le paiement en ligne, utilise la carte de test Stripe : `4242 4242 4242 4242`, date future, CVC `123`
3. Ouvre `https://ton-url.vercel.app/pizzaiolo` dans un autre onglet, connecte-toi avec le compte créé à l'étape 1.7
4. Tu dois voir la commande apparaître avec le bip sonore, dans la colonne "Nouvelles"
5. Fais-la avancer (En préparation → Prête) et vérifie que le statut se met à jour tout seul côté client

---

## Étape 6 — Passer en vrais paiements

1. Sur Stripe, active ton compte (informations légales de l'entreprise/auto-entreprise, IBAN)
2. Bascule le tableau de bord Stripe en **mode Live**, récupère la clé secrète **live** (`sk_live_...`)
3. Recrée un webhook en mode Live (même URL, même événement) pour obtenir un nouveau `whsec_...` live
4. Remplace `STRIPE_SECRET_KEY` et `STRIPE_WEBHOOK_SECRET` dans Vercel par les valeurs live, puis **Redeploy**

---

## Étape 7 — Générer le QR code et le lien Google Maps

1. Utilise un générateur de QR code gratuit (ex : `qr-code-generator.com`) avec l'URL `https://ton-url.vercel.app/commander`
2. Imprime le QR code (table, vitrine, ticket de caisse)
3. Ajoute le lien "Commander" sur ta fiche Google Business Profile (Google Maps)

---

## Limites connues de cette v1 (à garder en tête)

- La lecture des commandes (`orders`) est en accès public en base — acceptable pour démarrer, mais à sécuriser via une route API si le volume grandit (voir note dans `supabase/schema.sql`)
- Un seul jour de créneaux est géré (pas de gestion multi-jours pour l'instant)
- Pas encore de SMS/notification push si la tablette du pizzaiolo est en veille — il faut garder l'onglet `/pizzaiolo` ouvert et l'écran allumé
- Pas d'historique ni de statistiques de commandes au-delà de ce qui est affiché

---

## Besoin d'aide sur le code ?

Si tu bloques sur une étape technique (erreur au déploiement, message d'erreur incompréhensible),
le plus efficace est d'ouvrir ce dossier de projet avec **Claude Code** (l'appli bureau d'Anthropic) :
elle peut installer les dépendances, lancer le site en local, lire les messages d'erreur exacts et les corriger,
ce qu'un chat seul ne peut pas faire.
